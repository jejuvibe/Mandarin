import { AppSettings, Customer, Order } from '../types';

export const DEFAULT_SETTINGS: AppSettings = {
  farmName: '해찬솔 농원',
  sellerPhone: '010-4512-2448',
  bankInfo: {
    bankName: '카카오뱅크',
    accountNumber: '3333-06-7706075',
    accountHolder: '이정선',
  },
  pricing: {
    price5kg: 20000,
    price10kg: 25000,
    boxPrice5kg: 800,           // 5kg 박스 원가 800원
    boxPrice10kg: 1000,         // 10kg 박스 원가 1000원
    defaultShippingCost: 4500,  // 상자당 기본 택배비
  },
  defaultCarrier: '우체국택배',
  dispatchNoticeTemplate:
`[발송예정 안내]
{customerName} 고객님, 정성껏 수확한 노지감귤({itemSummary})이 {dispatchDate}에 {carrier}로 발송될 예정입니다.
감사합니다!`,
  bankNoticeTemplate:
`[주문 입금 안내]
{customerName}님, 제주 감귤 주문이 정상 접수되었습니다.

• 주문 내역: {itemSummary}
• 총 결제 금액: {totalAmount}원
• 입금 계좌: {bankName} {accountNumber}
• 예금주: {accountHolder}

입금 확인 후 수확하여 {dispatchDate}에 발송해 드립니다. 감사합니다.`,
  shippingNoticeTemplate:
`[배송 출발 안내]
{customerName}님, 주문하신 감귤({itemSummary})이 오늘 발송되었습니다.

• 택배사: {carrier}
• 운송장번호: {trackingNumber}
• 배송조회: {trackingUrl}

감사합니다.`,
  preOrderInquiryTemplate:
`[감귤 주문 안내]
산지 직거래 햇노지감귤 가격 및 주문 안내드립니다.

🍊 판매 가격
• 노지 감귤 10kg: {price10kg}원
• 노지 감귤 5kg: {price5kg}원
(택배비 포함 무료 배송)

🏦 입금 계좌
• {bankName} {accountNumber}
• 예금주: {accountHolder}

🚚 발송 안내
입금 확인 후 수확하는 시간이 최대 1주일 정도 소요될 예정입니다.

📝 주문 방법
입금 후 아래 정보를 문자로 남겨주시면 확인 후 발송해 드립니다:
1. 받는 분 성함:
2. 휴대전화 번호:
3. 배송지 주소:
4. 주문 수량(10kg / 5kg):
5. 배송 요청사항(선택):

감사합니다!`,
};

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'CUST-001',
    name: '김서연',
    phone: '010-3847-1928',
    address: '서울특별시 마포구 월드컵북로 400 102동 1403호',
    orderCount: 4,
    totalSpent: 100000,
    lastOrderedAt: '2026-11-23',
    notes: '매년 10kg 재구매하는 단골 고객님. 당도 높은 것 선호',
  },
  {
    id: 'CUST-002',
    name: '박민우',
    phone: '010-4921-8274',
    address: '경기도 성남시 분당구 판교역로 146 판교푸르지오 205동 801호',
    orderCount: 2,
    totalSpent: 45000,
    lastOrderedAt: '2026-11-24',
    notes: '직장 선물용, 5kg 소포장 선호',
  },
  {
    id: 'CUST-003',
    name: '이정희',
    phone: '010-7162-9384',
    address: '부산광역시 해운대구 센텀중앙로 78 센텀파크 101동 602호',
    orderCount: 5,
    totalSpent: 125000,
    lastOrderedAt: '2026-11-22',
    notes: '부모님 댁으로 정기 발송 요청',
  },
  {
    id: 'CUST-004',
    name: '최동현',
    phone: '010-8392-1049',
    address: '대전광역시 유성구 대학로 99 카이스트 교수아파트 3동 402호',
    orderCount: 1,
    totalSpent: 25000,
    lastOrderedAt: '2026-11-20',
  },
  {
    id: 'CUST-005',
    name: '한수진',
    phone: '010-2938-4712',
    address: '대구광역시 수성구 달구벌대로 2450 범어푸르지오 104동 1201호',
    orderCount: 3,
    totalSpent: 75000,
    lastOrderedAt: '2026-11-24',
    notes: '문 앞에 두고 문자 부탁하심',
  },
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-20270115-001',
    createdAt: '2027-01-15 11:20',
    customerName: '강호진',
    phone: '010-5829-3310',
    address: '서울특별시 송파구 올림픽로 300 롯데캐슬 103동 1502호',
    postalCode: '05551',
    items: [
      {
        id: 'ITEM-J1',
        type: '10kg',
        name: '노지 감귤 10kg',
        quantity: 1,
        unitPrice: 25000,
      },
    ],
    totalAmount: 25000,
    shippingCost: 4500,
    boxCost: 1000, // 10kg 박스 1개
    netProfit: 19500,
    status: 'delivered',
    dispatchDate: '2027-01-15',
    carrier: '우체국택배',
    trackingNumber: '6892341299901',
    memo: '1월 늦수확 고당도 감귤 요청',
    isPaid: true,
    paidAt: '2027-01-15 11:30',
  },
  {
    id: 'ORD-20261228-001',
    createdAt: '2026-12-28 15:40',
    customerName: '윤지현',
    phone: '010-6721-9988',
    address: '인천광역시 연수구 송도과학로 32 송도더샵 102동 804호',
    postalCode: '21984',
    items: [
      {
        id: 'ITEM-D1',
        type: '5kg',
        name: '노지 감귤 5kg',
        quantity: 2,
        unitPrice: 20000,
      },
    ],
    totalAmount: 40000,
    shippingCost: 9000,
    boxCost: 1600, // 5kg 박스 2개 (800 * 2)
    netProfit: 29400,
    status: 'delivered',
    dispatchDate: '2026-12-29',
    carrier: '우체국택배',
    trackingNumber: '6892341288812',
    memo: '연말 선물용',
    isPaid: true,
    paidAt: '2026-12-28 15:50',
  },
  {
    id: 'ORD-20261124-001',
    createdAt: '2026-11-24 14:20',
    customerName: '박민우',
    phone: '010-4921-8274',
    address: '경기도 성남시 분당구 판교역로 146 판교푸르지오 205동 801호',
    postalCode: '13524',
    items: [
      {
        id: 'ITEM-1',
        type: '5kg',
        name: '노지 감귤 5kg',
        quantity: 1,
        unitPrice: 20000,
      },
      {
        id: 'ITEM-2',
        type: '10kg',
        name: '노지 감귤 10kg',
        quantity: 1,
        unitPrice: 25000,
      },
    ],
    totalAmount: 45000,
    shippingCost: 9000, // 2박스 택배비
    boxCost: 1800,      // 5kg(800) + 10kg(1000)
    netProfit: 34200,
    status: 'order_received',
    dispatchDate: '2026-11-25',
    carrier: '우체국택배',
    trackingNumber: '',
    memo: '부재 시 경비실에 맡겨주세요',
    isPaid: true,
    paidAt: '2026-11-24 14:35',
  },
  {
    id: 'ORD-20261124-002',
    createdAt: '2026-11-24 11:05',
    customerName: '한수진',
    phone: '010-2938-4712',
    address: '대구광역시 수성구 달구벌대로 2450 범어푸르지오 104동 1201호',
    postalCode: '42089',
    items: [
      {
        id: 'ITEM-3',
        type: '10kg',
        name: '노지 감귤 10kg',
        quantity: 1,
        unitPrice: 25000,
      },
    ],
    totalAmount: 25000,
    shippingCost: 4500,
    boxCost: 1000, // 10kg 1개
    netProfit: 19500,
    status: 'payment_pending',
    dispatchDate: '2026-11-26',
    carrier: '우체국택배',
    trackingNumber: '',
    memo: '문 앞 배송 요망',
    isPaid: false,
  },
  {
    id: 'ORD-20261123-001',
    createdAt: '2026-11-23 16:40',
    customerName: '김서연',
    phone: '010-3847-1928',
    address: '서울특별시 마포구 월드컵북로 400 102동 1403호',
    postalCode: '03925',
    items: [
      {
        id: 'ITEM-4',
        type: '10kg',
        name: '노지 감귤 10kg',
        quantity: 2,
        unitPrice: 25000,
      },
    ],
    totalAmount: 50000,
    shippingCost: 9000,
    boxCost: 2000, // 10kg 2개 (1000 * 2)
    netProfit: 39000,
    status: 'order_received',
    dispatchDate: '2026-11-24',
    carrier: '우체국택배',
    trackingNumber: '6892341258901',
    memo: '배송 전 연락 부탁드립니다',
    isPaid: true,
    paidAt: '2026-11-23 16:50',
  },
  {
    id: 'ORD-20261122-001',
    createdAt: '2026-11-22 09:15',
    customerName: '이정희',
    phone: '010-7162-9384',
    address: '부산광역시 해운대구 센텀중앙로 78 센텀파크 101동 602호',
    postalCode: '48058',
    items: [
      {
        id: 'ITEM-5',
        type: '5kg',
        name: '노지 감귤 5kg',
        quantity: 2,
        unitPrice: 20000,
      },
    ],
    totalAmount: 40000,
    shippingCost: 9000,
    boxCost: 1600, // 5kg 2개 (800 * 2)
    netProfit: 29400,
    status: 'delivered',
    dispatchDate: '2026-11-22',
    carrier: '우체국택배',
    trackingNumber: '6892341257123',
    memo: '선물용 박스 포장',
    isPaid: true,
    paidAt: '2026-11-22 09:30',
  },
  {
    id: 'ORD-20261120-001',
    createdAt: '2026-11-20 13:10',
    customerName: '최동현',
    phone: '010-8392-1049',
    address: '대전광역시 유성구 대학로 99 카이스트 교수아파트 3동 402호',
    postalCode: '34141',
    items: [
      {
        id: 'ITEM-6',
        type: '10kg',
        name: '노지 감귤 10kg',
        quantity: 1,
        unitPrice: 25000,
      },
    ],
    totalAmount: 25000,
    shippingCost: 4500,
    boxCost: 1000, // 10kg 1개
    netProfit: 19500,
    status: 'delivered',
    dispatchDate: '2026-11-21',
    carrier: 'CJ대한통운',
    trackingNumber: '568192340192',
    memo: '',
    isPaid: true,
    paidAt: '2026-11-20 13:15',
  },
];
